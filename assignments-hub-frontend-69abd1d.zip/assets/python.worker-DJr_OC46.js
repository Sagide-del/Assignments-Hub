(function(){"use strict";const i="https://cdn.jsdelivr.net/pyodide/v0.27.7/full/";let r=null,l=!1,d=!1;const u=self.fetch.bind(self);let c=!1;Object.defineProperty(self,"fetch",{configurable:!1,writable:!1,value:(n,t)=>c?u(n,t):Promise.reject(new Error("fetch is not available to learner programs"))});async function f(n){c=!0;try{r||(r=import(`${i}pyodide.mjs`).then(o=>o.loadPyodide({indexURL:i})));const t=await r;return n==="MACHINE_LEARNING"&&!l&&(await t.loadPackage(["numpy"]),l=!0),t}catch(t){throw r=null,l=!1,t}finally{c=!1}}function b(n){return`import json
_robot_commands = []
def forward(steps=1):
    _robot_commands.append({"command": "forward", "value": int(steps)})
def backward(steps=1):
    _robot_commands.append({"command": "backward", "value": int(steps)})
def turn_left():
    _robot_commands.append({"command": "turn_left", "value": 1})
def turn_right():
    _robot_commands.append({"command": "turn_right", "value": 1})
${n}
print("__ROBOT_COMMANDS__" + json.dumps(_robot_commands))`}self.addEventListener("message",async n=>{if(n.data.type!=="RUN"||d)return;d=!0;const{requestId:t,mode:o,code:_,input:m=""}=n.data,s=[];let e;const p=a=>{if(s.join(`
`).length>3e4)throw new Error("Too much output. Try a smaller loop.");s.push(a)};try{e=await f(o),self.postMessage({type:"STARTED",requestId:t}),e.setStdout({batched:p}),e.setStderr({batched:p});const a=m?m.replace(/\r\n/g,`
`).split(`
`):[];e.setStdin({stdin:()=>a.shift()??null}),e.globals.set("__learner_code",o==="ROBOTICS"?b(_):_),await e.runPythonAsync(`__learner_namespace = {"__name__": "__main__"}
exec(compile(__learner_code, "<learner>", "exec"), __learner_namespace)`),self.postMessage({type:"RESULT",requestId:t,output:s.join(`
`)})}catch(a){self.postMessage({type:"ERROR",requestId:t,message:a instanceof Error?a.message:String(a),output:s.join(`
`)})}finally{e==null||e.globals.delete("__learner_code"),e==null||e.globals.delete("__learner_namespace"),d=!1}})})();
//# sourceMappingURL=python.worker-DJr_OC46.js.map
